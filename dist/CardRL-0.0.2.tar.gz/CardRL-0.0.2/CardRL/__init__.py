__name__="cardrl"

import deck
import games
