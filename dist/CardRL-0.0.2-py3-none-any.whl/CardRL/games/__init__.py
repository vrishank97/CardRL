__name__="texas"

import texas
